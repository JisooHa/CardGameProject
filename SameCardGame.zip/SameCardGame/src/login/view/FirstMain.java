package login.view;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.*;

import game.client.GameClient;
import play.multi.MultiGameDisplay;
import play.single.SingleGameDisplay;

public class FirstMain extends JFrame implements ActionListener {
	private JButton single, multi, exit; //버튼 3개 선언
	private JPanel southPane, southPaneBtn; 
	//순서대로 배경이미지를 삽입할 패널 > 버튼을 아래쪽에 위치하기위해 만든 패널 > 실제로 버튼이 들어가고, 버튼의 크기지정하기위해 만든 패널 
	private BufferedImage img = null; //이미지 
	private JLabel backgroundImg;

	public FirstMain() {
		this.setTitle("짝 맞추기 게임 - by.PLUS");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE); // 창 닫을때 프로그램 종료시킴
		//this.setLayout(null);
		this.setBounds(300, 100, 500, 600);
		
		try {	//이미지 불러오기
			img = ImageIO.read(new File("images/pica.jpg"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
			System.exit(0);
		}
		
		backgroundImg = new JLabel(new ImageIcon(img));
		
		
		single = new JButton("혼자하기"); 
		multi = new JButton("같이하기");
		exit = new JButton("나가기");
		
		southPane = new JPanel();
		southPaneBtn = new JPanel();
		
		
		southPane.setBounds(0, 350, 500, 200);
		
		
		southPane.setOpaque(false);  //패널의 투명도 설정, false=0%
		southPaneBtn.setOpaque(false);

		
		
		single.setPreferredSize(new Dimension(150, 40));
		
		southPaneBtn.add(single); //버튼을 패널에 삽입
		southPaneBtn.add(multi);
		southPaneBtn.add(exit);
		
		GridLayout grid = new GridLayout(3, 1); //버튼3개를 각각다른행에 삽입하기위해 행나눠줌
		southPaneBtn.setLayout(grid);	
			//버튼을 삽입한 패널을 아래쪽에 배치
		grid.setVgap(23);		//버튼사이의 간격 지정
		

		//각각 버튼 클릭했을때 액션을 추가
		multi.addActionListener(this);
		exit.addActionListener(this);
		single.addActionListener(this);	
		
		southPane.add(southPaneBtn, BorderLayout.CENTER);
		
		this.add(southPane);
		this.add(backgroundImg);//프레임 창에 메인패널 추가
		pack();
		setVisible(true);	//화면에 나타냄
	}


	@Override
	public void actionPerformed(ActionEvent event) {
		switch (event.getActionCommand()) {
		case "혼자하기":
			new SingleGameDisplay();	//혼자하기 클릭시 SingleGameDisplay 클래스 실행
			this.setVisible(false);
			break;
		case "같이하기":
			NicknameDialog nd = new NicknameDialog();
			nd.setVisible(true);
//			if(getNickName()!=null)
			this.setVisible(false);
			break;
		case "나가기":
			int result = JOptionPane.showConfirmDialog(getParent(), "게임을 종료하시겠습니까?", "게임 종료",
					JOptionPane.YES_NO_OPTION);
			if (result == 0)
				System.exit(0);
			break;
		}

	}
}