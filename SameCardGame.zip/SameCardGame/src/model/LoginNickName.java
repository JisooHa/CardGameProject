package model;

public class LoginNickName {
	private String nickName;

	public LoginNickName() {
	}

	public LoginNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
		System.out.println("닉네임 입력 후 : "+this.nickName);
	}

	@Override
	public String toString() {
		return nickName;
	}

}
