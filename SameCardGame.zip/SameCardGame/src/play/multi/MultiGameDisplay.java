package play.multi;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import java.awt.event.*;
import javax.swing.event.*;

import login.view.FirstMain;
import login.view.LoginNickName;
import login.view.NicknameDialog;

public class MultiGameDisplay extends JFrame implements ActionListener  {
	private JButton[] card = new JButton[24];
	private JButton start, exit;
	private JLabel myScoreLabel;
	private JLabel otherScoreLabel;
	private int score=0;
	private JPanel gamePane, rightPane, btnPane, scorePane;
	private ImageIcon imageIcon[]=new ImageIcon[20] ;			// 앞면 이미지 저장할 20개 아이콘들

	public MultiGameDisplay(String userNick) {
	
		System.out.println("게임화면 닉네임 : "+userNick);
		System.out.println("멀티게임실행");

		this.setTitle("카드 짝맞추기 - 멀티게임");
		this.setBounds(new Rectangle(50,50,1100,800));
		this.setLayout(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE); // 창 닫을때 프로그램 종료시킴

		 
		//게임 부분
		gamePane = new JPanel(new GridLayout(4,6));
		gamePane.setBounds(0,0,800,760);
		
		
		for(int i=0; i<card.length; i++){
			card[i] = new JButton(new ImageIcon("images/화투 그림/"+(i+1)+ ".jpg"));
			gamePane.add(card[i]);
		}
		
		
		//스코어,버튼 부분
		rightPane = new JPanel(new BorderLayout());
		scorePane = new JPanel();
		GridLayout grid = new GridLayout(2, 1);
		btnPane = new JPanel(grid);
		
		
		myScoreLabel = new JLabel(userNick+"님의 점수 : ");
		start = new JButton("게임시작");
		exit = new JButton("나가기");
		
		
		rightPane.setBounds(830, 20, 225,720);
		
		scorePane.setPreferredSize(new Dimension(200, 200));	
		scorePane.setBackground(Color.WHITE);
		scorePane.setBorder(BorderFactory.createLoweredBevelBorder()); //스코어부분 테두리 bevelBorder
		
		btnPane.setPreferredSize(new Dimension(200, 100));
		
		start.setPreferredSize(new Dimension(60, 50));
		grid.setVgap(23);
		
		exit.addActionListener(this);
	
		
		rightPane.add(scorePane, BorderLayout.NORTH);
		rightPane.add(btnPane, BorderLayout.SOUTH);
		scorePane.add(myScoreLabel);
		btnPane.add(start);
		btnPane.add(exit);
		
		this.add(gamePane, BorderLayout.WEST);
		this.add(rightPane, BorderLayout.EAST);
		
		this.setVisible(true);

	}

	

	@Override
	public void actionPerformed(ActionEvent event) {
		switch (event.getActionCommand()) {
		case "게임시작":
			
			break;
		case "나가기":
			int result = JOptionPane.showConfirmDialog(getParent(), "메인화면으로 돌아가시겠습니까?", "게임 나가기",
					JOptionPane.YES_NO_OPTION);
			if (result == 0){
				new FirstMain();
				this.setVisible(false);
			}
				break;
		}

	}
}